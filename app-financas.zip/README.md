# Minhas finanças: app para o iPhone

Um app seu, sem Telegram nem servidor. Os dados ficam guardados no próprio iPhone e ele funciona até sem internet.

## O que ele faz
- **Anotar:** digite `45 pizza` ou `+1500 salário`. O app mostra a categoria antes de você salvar; se não reconhecer a palavra, você escolhe a categoria com um toque e ele aprende para a próxima vez.
- **Limites:** cada categoria tem uma barra. Ela fica rosada a partir de 80% e vermelha quando passa do limite. O traço fino na barra marca quanto você teria gastado até hoje se dividisse o limite por igual entre os dias do mês.
- **Alertas:** aparecem na hora em que você anota: ao chegar a 80% (com a previsão do dia em que o limite acaba) e ao passar de 100%.
- **Meta de investimento:** avisa quando você bate a meta e, nos últimos dias do mês, se ainda falta investir. Depois de anotar uma entrada, oferece anotar o que falta para a meta.
- **Lançamentos:** histórico do mês por dia, com filtro por categoria. Toque num lançamento para trocar a categoria ou apagar.
- **Ajustes:** limites, meta, palavras-chave, novas categorias e backup.

Na primeira vez ele abre com **lançamentos de exemplo**. Toque em "Apagar exemplos e começar" e defina seus limites em Ajustes.

## Publicar no GitHub Pages (grátis, uns 10 minutos)

1. Crie uma conta em github.com, se ainda não tiver.
2. Clique em **New repository**. Dê um nome (ex.: `financas`), marque **Public** e clique em **Create repository**.
3. Na página do repositório, clique em **uploading an existing file** e arraste **todos os arquivos desta pasta** (`index.html`, `manifest.json`, `sw.js` e os três `icon-*.png`). Clique em **Commit changes**.
4. Vá em **Settings → Pages**. Em *Source*, escolha **Deploy from a branch**, depois a branch **main** e a pasta **/ (root)**, e clique em **Save**.
5. Espere um ou dois minutos e recarregue a página. Aparece o endereço do app, algo como `https://seu-usuario.github.io/financas/`.

> O repositório público mostra o **código** do app, não os seus dados: eles ficam só no seu celular.

## Instalar no iPhone

1. Abra o endereço no **Safari** (precisa ser o Safari).
2. Toque em **Compartilhar** (o quadrado com a seta) e depois em **Adicionar à Tela de Início**.
3. Pronto: o ícone "Finanças" aparece na tela e o app abre em tela cheia.

Use sempre pelo ícone. Se abrir pelo Safari normal, ele não enxerga os dados do app instalado (são guardados separados).

## Backup (importante)

Os dados ficam só no iPhone. Se você apagar o app, eles vão junto. Em **Ajustes → Backup**:
- **Salvar backup**: gera um arquivo que você guarda no Arquivos, no Drive ou num e-mail para você.
- **Restaurar backup**: carrega esse arquivo de volta (por exemplo, num celular novo).
- **Exportar planilha (CSV)**: abre no Excel ou no Google Sheets.

Faça um backup de vez em quando, tipo no fim de cada mês.

## Atualizar o app depois
Para trocar algum arquivo, suba a versão nova no mesmo repositório. No `sw.js`, mude `financas-v1` para `financas-v2` (e assim por diante): é isso que avisa o iPhone que tem versão nova. Seus dados não são apagados.
